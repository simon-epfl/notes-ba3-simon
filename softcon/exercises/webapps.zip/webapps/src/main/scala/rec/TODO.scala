package rec

/** Using ??? in a val breaks worksheet evaluation, so below we use TODO
  * instead. This TODO value is a hack; we don't expect you to understand how it
  * works!
  */
def TODO[A]: A = null.asInstanceOf[A]
